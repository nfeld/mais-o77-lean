"""Failure-path tests using fake tool commands: no Lean/Podman/network execution."""
import fcntl
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PIN = '664cbbe52927ce6acaa39ca35498336116e123b8'
FAKE = r'''#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
name = pathlib.Path(sys.argv[0]).name
args = sys.argv[1:]
with open(os.environ['CALLS'], 'a') as f:
    f.write(json.dumps([name, *args]) + '\n')
if name == 'cp':
    if os.environ.get('FAIL_COPY') == '1' and args[-2] == os.environ['INPUT_SOURCE']:
        sys.exit(17)
    sys.exit(subprocess.run([os.environ['REAL_CP'], *args]).returncode)
if name == 'cmp':
    if os.environ.get('FAIL_COMPARE') == '1': sys.exit(1)
    sys.exit(subprocess.run([os.environ['REAL_CMP'], *args]).returncode)
if name == 'git':
    if 'rev-parse' in args: print(os.environ.get('MOCK_PIN', '664cbbe52927ce6acaa39ca35498336116e123b8'))
    if 'diff' in args: sys.exit(int(os.environ.get('MOCK_DIRTY', '0')))
elif name == 'lean':
    print('MOCK Lean version; no compiler was invoked')
elif name == 'lake':
    if args[:1] == ['build']: sys.exit(int(os.environ.get('BUILD_STATUS', '0')))
    if 'leanchecker' in args: sys.exit(int(os.environ.get('REPLAY_STATUS', '0')))
    if 'lean' in args: sys.exit(int(os.environ.get('VERIFY_STATUS', '0')))
    print('MOCK Lake; no compiler was invoked')
elif name == 'podman':
    if args == ['--version']: print('MOCK Podman; no container was invoked')
    elif args[:2] == ['image', 'inspect']: print('sha256:mock-image-id')
    elif args[:1] == ['run']:
        print('MOCK container output')
        sys.exit(int(os.environ.get('CONTAINER_STATUS', '0')))
elif name == 'tee':
    status = subprocess.run([os.environ['REAL_TEE'], *args]).returncode
    sys.exit(int(os.environ.get('TEE_STATUS', str(status))))
else:
    raise SystemExit('unexpected fake command: ' + name)
'''


class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='o77-tests-', dir=ROOT.parent)
        self.base = Path(self.tmp.name)
        self.project = self.base / 'project'
        self.project.mkdir()
        (self.project / 'lake-manifest.json').write_text('{}\n')
        for name in ('lean-toolchain', 'lakefile.toml'):
            shutil.copyfile(ROOT / 'project' / name, self.project / name)
        self.source = self.base / 'source with spaces.lean'
        self.source.write_text('-- mock source, deliberately no Lean code\n')
        (self.project / 'O77Target.lean').write_text('stale previous source\n')
        self.bin = self.base / 'bin'
        self.bin.mkdir()
        for name in ('cp', 'cmp', 'git', 'lean', 'lake', 'podman', 'tee'):
            p = self.bin / name
            p.write_text(FAKE)
            p.chmod(0o755)
        self.calls_file = self.base / 'calls.jsonl'
        self.env = dict(os.environ, PATH=str(self.bin) + os.pathsep + os.environ['PATH'],
                        CALLS=str(self.calls_file), INPUT_SOURCE=str(self.source),
                        REAL_CP=shutil.which('cp'), REAL_CMP=shutil.which('cmp'),
                        REAL_TEE=shutil.which('tee'), O77_PROJECT=str(self.project),
                        O77_CONFIG_DIR=str(ROOT / 'project'),
                        O77_LOG_DIR=str(self.base / 'logs'), FRESH='0')

    def tearDown(self):
        self.tmp.cleanup()

    def run_script(self, script='in-container-recheck.sh', args=None, **env):
        command = ['bash', str(ROOT / 'scripts' / script)]
        command.extend([str(self.source)] if args is None else args)
        return subprocess.run(command, env=dict(self.env, **env), capture_output=True, text=True)

    def calls(self):
        if not self.calls_file.exists():
            return []
        return [json.loads(x) for x in self.calls_file.read_text().splitlines()]

    def host(self, *args, **env):
        return subprocess.run(['bash', str(ROOT / 'o77.sh'), *args],
                              env=dict(self.env, **env), capture_output=True, text=True)

    def assert_no_build(self):
        self.assertFalse(any(x[:2] == ['lake', 'build'] for x in self.calls()))
        self.assertFalse(any('leanchecker' in x for x in self.calls()))

    def test_success_copies_exact_file_before_replay(self):
        result = self.run_script()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual((self.project / 'O77Target.lean').read_bytes(), self.source.read_bytes())
        calls = self.calls()
        self.assertLess(calls.index(['lake', 'build', 'O77Target']),
                        calls.index(['lake', 'env', 'leanchecker', 'O77Target']))
        self.assertIn('KERNEL RE-CHECK PASSED.', result.stdout)

    def test_lock_prevents_simultaneous_source_replacement(self):
        with open(self.project / '.o77-run.lock', 'w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            result = self.run_script()
            self.assertNotEqual(result.returncode, 0)
            self.assert_no_build()
            self.assertEqual((self.project / 'O77Target.lean').read_text(), 'stale previous source\n')

    def test_setup_mock_success_cleans_warmup_file(self):
        result = self.run_script('in-container-setup.sh', args=[])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn(['lake', 'exe', 'cache', 'get'], self.calls())
        self.assertEqual(list(self.project.glob('O77Warm*.lean')), [])

    def test_copy_failure_never_builds_stale_source(self):
        result = self.run_script(FAIL_COPY='1')
        self.assertNotEqual(result.returncode, 0)
        self.assert_no_build()
        self.assertEqual((self.project / 'O77Target.lean').read_text(), 'stale previous source\n')
        self.assertNotIn('KERNEL RE-CHECK PASSED', result.stdout)

    def test_copy_mismatch_aborts(self):
        self.assertNotEqual(self.run_script(FAIL_COMPARE='1').returncode, 0)
        self.assert_no_build()

    def test_missing_source_aborts(self):
        self.assertNotEqual(self.run_script(args=[str(self.base / 'missing')]).returncode, 0)
        self.assert_no_build()

    def test_missing_configuration_aborts(self):
        self.assertNotEqual(self.run_script(O77_CONFIG_DIR=str(self.base / 'missing')).returncode, 0)
        self.assert_no_build()

    def test_wrong_mathlib_pin_aborts(self):
        self.assertNotEqual(self.run_script(MOCK_PIN='wrong').returncode, 0)
        self.assert_no_build()

    def test_dirty_mathlib_aborts(self):
        self.assertNotEqual(self.run_script(MOCK_DIRTY='1').returncode, 0)
        self.assert_no_build()

    def test_build_failure_skips_replay(self):
        result = self.run_script(BUILD_STATUS='23')
        self.assertEqual(result.returncode, 23)
        self.assertFalse(any('leanchecker' in x for x in self.calls()))
        self.assertNotIn('KERNEL RE-CHECK PASSED', result.stdout)

    def test_replay_failure_is_preserved(self):
        result = self.run_script(REPLAY_STATUS='24')
        self.assertEqual(result.returncode, 24)
        self.assertNotIn('KERNEL RE-CHECK PASSED', result.stdout)

    def test_fresh_is_forwarded(self):
        self.assertEqual(self.run_script(FRESH='1').returncode, 0)
        self.assertIn(['lake', 'env', 'leanchecker', '--fresh', 'O77Target'], self.calls())

    def test_invalid_fresh_is_rejected(self):
        self.assertNotEqual(self.run_script(FRESH='yes').returncode, 0)
        self.assert_no_build()

    def test_verify_failure_is_preserved(self):
        result = self.run_script('in-container-verify.sh', VERIFY_STATUS='25')
        self.assertEqual(result.returncode, 25)
        self.assertNotIn('ELABORATION PASSED', result.stdout)

    def test_probe_uses_unchanged_input_and_examples(self):
        probes = ROOT / 'tools' / 'Probes.lean'
        result = self.run_script('in-container-probe.sh', args=[str(self.source), str(probes)])
        self.assertEqual(result.returncode, 0, result.stderr)
        combined = (self.project / 'O77WithProbes.lean').read_bytes()
        self.assertTrue(combined.startswith(self.source.read_bytes()))
        self.assertTrue(combined.endswith(probes.read_bytes()))
        self.assertEqual(self.source.read_text(), '-- mock source, deliberately no Lean code\n')

    def test_missing_probe_fails(self):
        result = self.run_script('in-container-probe.sh', args=[str(self.source), str(self.base / 'none')])
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('STATEMENT-SHAPE PROBES PASSED', result.stdout)

    def test_host_propagates_failed_container_through_tee(self):
        result = self.host('recheck', str(self.source), CONTAINER_STATUS='26')
        self.assertEqual(result.returncode, 26, result.stderr)
        logs = list((self.base / 'logs').glob('*.log'))
        self.assertEqual(len(logs), 1)
        self.assertIn('Container/check exit status: 26', logs[0].read_text())

    def test_host_fails_if_log_writer_fails(self):
        self.assertEqual(self.host('recheck', str(self.source), TEE_STATUS='27').returncode, 27)

    def test_host_rejects_multiple_files(self):
        result = self.host('recheck', str(self.source), str(self.source))
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(any(x[:2] == ['podman', 'run'] for x in self.calls()))

    def test_batch_run_is_offline_readonly_and_has_no_tty(self):
        result = self.host('recheck', str(self.source))
        self.assertEqual(result.returncode, 0, result.stderr)
        command = next(x for x in self.calls() if x[:2] == ['podman', 'run'])
        self.assertIn('--network=none', command)
        self.assertIn('--security-opt=no-new-privileges', command)
        self.assertIn(str(self.source) + ':/input/O77Target.lean:ro,Z', command)
        self.assertNotIn('-it', command)
        self.assertNotIn('-t', command)

    def test_invalid_host_fresh_rejected_before_run(self):
        self.assertNotEqual(self.host('recheck', str(self.source), FRESH='invalid').returncode, 0)
        self.assertFalse(any(x[:2] == ['podman', 'run'] for x in self.calls()))


class DiagnosticTests(unittest.TestCase):
    def test_partial_ansi_log_does_not_claim_success(self):
        with tempfile.TemporaryDirectory(dir=ROOT.parent) as name:
            folder = Path(name)
            source, log = folder / 'test.lean', folder / 'partial.log'
            source.write_text('/- BEGIN A -/\nexample : True := by trivial\n-- END A\n')
            log.write_text('\x1b[31m/input/with spaces.lean:2:1: error: example failure\x1b[0m\n'
                           'case goal\n\nwarning: /input/test.lean:2:1: warning message\n')
            result = subprocess.run(['python3', str(ROOT / 'tools' / 'report_errors.py'),
                                     str(log), str(source)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)
            self.assertIn('TOTAL: 1 errors, 1 warnings', result.stdout)
            self.assertNotIn('clean', result.stdout)
            self.assertIn('not a compilation-success certificate', result.stdout)


if __name__ == '__main__':
    unittest.main()
