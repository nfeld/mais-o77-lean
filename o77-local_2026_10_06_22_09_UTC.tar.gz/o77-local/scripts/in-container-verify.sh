#!/usr/bin/env bash
# Elaborate the copied source; recheck additionally builds and replays an .olean.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
[ "$#" -le 1 ] || fail 'Pass exactly one source file.'
prepare_check "${1:-/input/O77Target.lean}"
# Options are whitespace-separated arguments, not evaluated as shell code.
options=()
read -r -a options <<< "${EXTRA_OPTS:--DmaxErrors=0}"
printf '==> lake env lean'; printf ' %q' "${options[@]}" O77Target.lean; printf '\n'
if time lake env lean "${options[@]}" O77Target.lean; then
  echo 'ELABORATION PASSED (exit 0). Read the log separately for any warnings.'
  echo 'Use recheck for compiled-module replay. Human specification review remains separate.'
else
  status=$?
  echo "Elaboration failed (exit $status)."
  exit "$status"
fi
