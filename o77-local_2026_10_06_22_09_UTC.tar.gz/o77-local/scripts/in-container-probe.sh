#!/usr/bin/env bash
# Append existing statement-shape examples without changing the submitted source.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
[ "$#" -le 2 ] || fail 'Usage: in-container-probe.sh SOURCE [PROBES]'
prepare_check "${1:-/input/O77Target.lean}"
probes=${2:-/opt/tools/Probes.lean}
[ -f "$probes" ] || fail "Probe file missing: $probes"
echo 'Probe file hash:'
sha256sum "$probes"
# The bundled probes contain no imports; do not silently rewrite arbitrary code.
if grep -Eq '^[[:space:]]*import[[:space:]]' "$probes"; then
  fail 'Probe file must contain no imports when appended to the submitted source.'
fi
cat O77Target.lean > O77WithProbes.lean
printf '\n\n-- Appended statement-shape probes\n\n' >> O77WithProbes.lean
cat -- "$probes" >> O77WithProbes.lean
echo 'Combined source hash:'
sha256sum O77WithProbes.lean
if time lake env lean -DmaxErrors=0 O77WithProbes.lean; then
  echo 'STATEMENT-SHAPE PROBES PASSED (exit 0).'
  echo 'These examples check selected clauses and existence consequences only.'
  echo 'They do not establish that the underlying definitions match the intended mathematics.'
else
  status=$?
  echo "Probe elaboration failed (exit $status). Inspect both the source and the probes."
  exit "$status"
fi
