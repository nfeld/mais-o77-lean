#!/usr/bin/env bash
# Network-enabled setup; ordinary checking runs use network=none.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
mkdir -p "$O77_PROJECT"
enter_project
refresh_config
lake --version
# Reuse an existing manifest only if Mathlib already has the required revision.
resolved=$(git -C .lake/packages/mathlib rev-parse HEAD 2>/dev/null || true)
if [ ! -f lake-manifest.json ] || [ "$resolved" != "$O77_PIN" ]; then
  lake update mathlib
fi
check_environment
print_environment
lake exe cache get
warm=$(mktemp "$O77_PROJECT/O77WarmXXXXXX.lean")
trap 'rm -f -- "$warm"' EXIT
printf 'import Mathlib\n' > "$warm"
lake env lean "$warm"
echo 'Setup completed. The dependency volume is ready for offline checking.'
