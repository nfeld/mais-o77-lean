# Rechecking the O77 Lean development locally

This folder builds and checks a caller-supplied Lean file in a Podman container.
It does not contain or modify the mathematical proof. Keep the published source
at the repository root, with its existing timestamped filename.

The current checkpoint is `O77Full_2026_10_06_20_50_UTC.lean`. Its final theorem
is `O77.answersO77`: the Wishart premise of the earlier conditional endpoint has
been discharged in this development. The theorem retains its stated positive
input/output dimension and target-rank hypotheses. The formal target concerns
radius-first band-volume asymptotics; it is not a formalization of meromorphic
continuation or zeta-pole identification. Human review of the mathematical
interpretation and specification is ongoing.

## Quick start

On a Linux host with Bash and rootless Podman installed, place this folder next
to the Lean file and run:

```bash
cd o77-local
chmod +x o77.sh
./o77.sh preflight
./o77.sh build
./o77.sh setup
./o77.sh doctor
./o77.sh recheck ../O77Full_2026_10_06_20_50_UTC.lean
```

You may instead give an absolute filename, for example:

```bash
./o77.sh recheck ~/Downloads/O77Full_2026_10_06_20_50_UTC.lean
```

Pass exactly one file; a glob matching several files is rejected. The script
uses Podman, not the Docker command-line program. On Debian/Ubuntu systems,
Podman is available through the system package manager (`sudo apt install
podman`). Consult your distribution's rootless Podman instructions if user
namespaces are unavailable; this package does not recommend disabling system
security controls globally.

Setup needs network access and substantial disk space for Lean/Mathlib and
cached compiled files. Plan for several GB of RAM and tens of GB of available
disk, with actual requirements depending on the machine and cache state.
Subsequent `verify`, `recheck`, `probe`, and `doctor` containers have networking
disabled. If they report a missing toolchain or dependency, rerun `setup`.

**Upgrading from the original folder:** run both `build` and `setup` once. The
updated image puts downloaded Lean toolchains in the persistent named volume;
the original image could download them again in each temporary container.
The existing `o77-lean` dependency volume can be reused. Preserve any old folder
and its logs before replacing it.

## Pins and reproducibility

| Component | Pin |
|---|---|
| Lean toolchain | `leanprover/lean4:v4.34.0-rc2` |
| Mathlib | `664cbbe52927ce6acaa39ca35498336116e123b8` |
| Published source SHA-256 | `54dd6627468f7f1ad19784b8085e567806d0a087095a1f56a99bb920436acacc` |

The scripts check the resolved Mathlib revision and reject tracked changes in
that checkout. Every new check records the input/copy hashes, container image
ID, Lean/Lake versions, configuration hashes, and resolved Lake manifest.
The dependency manifest is generated during setup, not fabricated in this
package. To save it separately:

```bash
./o77.sh manifest > lake-manifest.json
```

The Ubuntu image tag and elan installer are not pinned to content digests.
These instructions reproduce the pinned Lean/Mathlib checking environment;
they do not promise a byte-identical operating-system image. A new source hash
identifies a different checkpoint, even if its filename is unchanged.

## What each command checks

- `recheck FILE`: copies the source byte-for-byte into the container's project
  as `O77Target.lean`, runs `lake build O77Target`, then runs
  `lake env leanchecker O77Target`.
- `FRESH=1 ./o77.sh recheck FILE`: uses `leanchecker --fresh O77Target`, replaying
  imported constants as well. This can take substantially longer.
- `verify FILE`: runs `lake env lean -DmaxErrors=0 O77Target.lean` on the copied
  source. It elaborates without the additional compiled-module replay.
- `probe FILE`: appends the examples in `tools/Probes.lean` to a separate copy
  and elaborates it. These test selected statement shapes and existence
  consequences, not complete semantic adequacy.
- `doctor`: checks and prints the resolved environment; it proves no theorem.
- `report LOG SOURCE`: summarizes detected error/warning diagnostics. An empty
  diagnostic summary is not evidence of successful completion.

The known October 6 source has **seven** `#guard_msgs` axiom checks. In particular,
the final theorem's guard requires the axiom report to be exactly
`[propext, Classical.choice, Quot.sound]`. A successful build of that exact file
therefore checks this guard. A different input file need not contain it; this
harness does not silently assume that all submitted files carry axiom guards.

`leanchecker` reuses Lean's kernel. A separate replay is useful additional
checking, but is not an independently implemented proof checker. Default replay
starts with the imported environment; `--fresh` also replays imports. Neither
mode establishes that the definitions say what a human intends. Review the
actual theorem statements, measures, norms, inequalities, and quantifiers.
See [COMPARATOR.md](COMPARATOR.md) for this distinction and the scope of probes.

On failure, the script returns nonzero, preserves the log, and does not print a
success message for that failed stage. Exit zero does not by itself mean no
warnings occurred; inspect the full log. Informational output from `#check` or
`#print` is not an error. `EXTRA_OPTS` is available for `verify` only; it accepts
whitespace-separated arguments without shell evaluation.

## Isolation and local state

The container runs as its unprivileged `lean` user. Use rootless Podman on the
host. During batch checking the submitted source, scripts, configuration, and
probe files are mounted read-only. The home directory and repository as a whole
are not mounted. The container can write its named dependency volume; the host
driver writes new logs under `logs/`. Build/setup use the network, while checks
use `--network=none` and `--security-opt=no-new-privileges`.

Lean source elaboration can execute metaprograms. A text scan for a few keywords
cannot certify that arbitrary source is inert. Containers reduce exposure; they
are not a proof of safety against all host-kernel or container-runtime defects.
The writable dependency volume is shared between runs. If checking unrelated,
untrusted code, use a separate volume, for example `O77_VOLUME=o77-review-2`
with both `setup` and subsequent checking commands.

Checking scripts serialize their access to the common project with a lock.
Do not edit the volume concurrently through an interactive shell or editor,
which does not acquire that lock. `./o77.sh shell` provides an offline shell.
The optional `.devcontainer/` configuration is for interactive VS Code use,
after setup; select Podman for Dev Containers. Editor sessions are a different
workflow and can mount the workspace read-write. The supplied editor config
uses the default `o77-lean` volume and has not been exercised in this refresh.

`./o77.sh clean` explicitly removes this workflow's image and volume. It does
not delete source files or logs. Image/volume removal errors are reported.

## Files to publish

Publish this unpacked folder alongside the Lean source and manuscript. The
`logs/` directory includes three original user-supplied logs, retained byte for
byte. Its README identifies their checkpoints and limits. New logs are ignored
by Git by default; deliberately add a particular new verification record when
publishing a new checkpoint.

The source is never renamed on the host. `O77Target.lean` is only the internal
Lake module name. Historical logs were produced by the older scripts, not by
this revised package; see [CHANGELOG.md](CHANGELOG.md). No container or Lean run
was performed during this package refresh. The shell syntax and mocked failure
paths were tested; repeat `build`, `setup`, and `recheck` locally for an execution
receipt for these revised scripts.

The original local harness was supplied by Niels Feld and, by his account,
written mainly with Claude Opus 5.0. This revision updates its documentation and
failure handling with OpenAI assistance. This attribution concerns the checking
harness; the manuscript and repository acknowledgements describe mathematical
contributions separately. No license choice is made on the authors' behalf by
this package refresh; publish the applicable repository license alongside it.

## References

- [Lean: validating proofs](https://lean-lang.org/doc/reference/latest/ValidatingProofs/)
- [Lean checker documentation](https://github.com/leanprover/lean4checker)
- [Podman run options](https://docs.podman.io/en/stable/markdown/podman-run.1.html)

For the development tests, requiring only Python 3 and Bash:

```bash
python3 -m unittest discover -s tests -v
```

These tests use fake commands and do not run Lean, Podman, or network downloads.
