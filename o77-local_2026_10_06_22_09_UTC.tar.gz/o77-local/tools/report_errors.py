#!/usr/bin/env python3
"""Summarize detected Lean diagnostics, without inferring compilation success.

Usage: report_errors.py LOG_FILE SOURCE.lean [--errors-only]
The checker exit status and axiom guards remain authoritative. A partial log
with no diagnostics does not establish that any module finished elaborating.
"""
import argparse
import re
from collections import Counter
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
DIAG = re.compile(
    r"^(?:(?:error|warning):\s*)?(?P<path>.+?):(?P<line>\d+):(?P<col>\d+):\s*"
    r"(?P<sev>error|warning)\b"
)
LAKE_DIAG = re.compile(
    r"^(?P<sev>error|warning):\s*(?P<path>.+?):(?P<line>\d+):(?P<col>\d+):"
)
BEGIN = re.compile(r"^/- BEGIN (\S+)")
END = re.compile(r"^-- END (\S+)")


def modules(source):
    result, start, name = [], None, None
    for line, text in enumerate(source.splitlines(), 1):
        begin, end = BEGIN.match(text), END.match(text)
        if begin:
            start, name = line, begin.group(1)
        if end and start is not None:
            result.append((name, start, line))
            start = None
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', type=Path)
    parser.add_argument('source', type=Path)
    parser.add_argument('--errors-only', action='store_true')
    args = parser.parse_args()
    spans = modules(args.source.read_text(encoding='utf-8'))
    lines = ANSI.sub('', args.log.read_text(encoding='utf-8', errors='replace')).splitlines()
    counts, errors = Counter(), []
    for i, text in enumerate(lines):
        match = DIAG.match(text) or LAKE_DIAG.match(text)
        if not match:
            continue
        line = int(match['line'])
        name = next((n for n, a, b in spans if a <= line <= b), '<outside module markers>')
        counts[name, match['sev']] += 1
        if match['sev'] == 'error':
            block = [text]
            for following in lines[i + 1:]:
                if DIAG.match(following) or LAKE_DIAG.match(following) or not following.strip():
                    break
                block.append(following)
            errors.append((name, '\n'.join(block)))
    if args.errors_only:
        for name, block in errors:
            print(f'[{name}]\n{block}\n')
        return
    print('Detected diagnostics (not a compilation-success certificate):')
    print(f'{"module":44} {"errors":>7} {"warnings":>9}')
    for name in dict.fromkeys([n for n, _, _ in spans] + [n for n, _ in counts]):
        print(f'{name:44} {counts[name, "error"]:7} {counts[name, "warning"]:9}')
    print(f'TOTAL: {sum(v for (n, s), v in counts.items() if s == "error")} errors, '
          f'{sum(v for (n, s), v in counts.items() if s == "warning")} warnings')
    print('Inspect the full log and process exit status, especially for interrupted runs.')


if __name__ == '__main__':
    main()
