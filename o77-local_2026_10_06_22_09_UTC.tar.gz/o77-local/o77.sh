#!/usr/bin/env bash
# Local Podman workflow for the exact O77 source file supplied by the caller.
set -euo pipefail
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
IMAGE=${O77_IMAGE:-o77-lean:latest}
VOLUME=${O77_VOLUME:-o77-lean}
LOG_DIR=${O77_LOG_DIR:-$HERE/logs}

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
info() { printf '==> %s\n' "$*"; }
need_podman() { command -v podman >/dev/null || die 'Install Podman first (see README.md).'; }
no_args() { [ "$#" -eq 0 ] || die 'Unexpected extra arguments.'; }

usage() {
  cat <<'HELP'
Usage: ./o77.sh COMMAND [arguments]
  preflight           show local prerequisites and available resources
  build               build the container image (network required)
  setup               resolve pinned dependencies and fetch cache (network required)
  doctor              print/check the resolved environment, without network access
  verify FILE.lean    elaborate exactly one source file; preserve its exit status
  recheck FILE.lean   build and replay exactly one source file with leanchecker
  probe FILE.lean     elaborate source plus bundled statement-shape examples
  report LOG SOURCE  summarize diagnostics; this is not a proof check
  manifest            print the resolved Lake manifest as JSON
  shell               open an offline shell in the dependency volume
  clean               remove this workflow's image and dependency volume
  help                show this message
Environment:
  FRESH=1             recheck imports too, using leanchecker --fresh (default: 0)
  O77_IMAGE           container image name (default: o77-lean:latest)
  O77_VOLUME          dependency volume (default: o77-lean)
  O77_LOG_DIR         output directory for new logs (default: ./logs)
  EXTRA_OPTS          verify-only Lean options; whitespace-separated, no shell evaluation
Use explicit filenames: no automatic selection of a supposedly latest checkpoint.
HELP
}

cmd_preflight() {
  no_args "$@"
  command -v podman >/dev/null && podman --version || echo 'Podman: not installed'
  command -v python3 >/dev/null || echo 'Python 3: missing (needed for report and tests)'
  if [ -r /proc/meminfo ]; then
    awk '/MemTotal/ {printf "RAM: %.1f GiB\n", $2/1048576}' /proc/meminfo
  fi
  df -h "$HERE"
  echo 'Allow several GB of RAM and tens of GB of disk; use your prior run as a guide.'
  echo 'Use rootless Podman. If it fails, consult your distribution documentation.'
}

cmd_build() {
  no_args "$@"; need_podman
  podman build -t "$IMAGE" -f "$HERE/Containerfile" "$HERE"
}

cmd_setup() {
  no_args "$@"; need_podman
  if ! podman volume inspect "$VOLUME" >/dev/null 2>&1; then
    podman volume create "$VOLUME" >/dev/null
  fi
  podman run --rm --security-opt=no-new-privileges \
    -v "$VOLUME":/work \
    -v "$HERE/project":/opt/project:ro,Z \
    -v "$HERE/scripts":/opt/scripts:ro,Z \
    "$IMAGE" bash /opt/scripts/in-container-setup.sh
}

cmd_check() {
  local action=$1; shift
  [ "$#" -eq 1 ] || die "Usage: ./o77.sh $action FILE.lean (exactly one file)"
  [ -f "$1" ] || die "No such source file: $1"
  need_podman
  local abs log
  abs=$(readlink -f -- "$1")
  # Colon is Podman's -v delimiter; refuse ambiguous bind-mount paths.
  [[ "$abs" != *:* && "$HERE" != *:* ]] || die 'Bind-mount paths must not contain a colon.'
  [[ "${FRESH:-0}" = 0 || "${FRESH:-0}" = 1 ]] || die 'FRESH must be 0 or 1.'
  mkdir -p "$LOG_DIR"
  log=$(mktemp "$LOG_DIR/${action}-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX.log")
  {
    printf 'UTC: '; date -u +%Y-%m-%dT%H:%M:%SZ
    printf 'Action: %s\nInput basename: %s\n' "$action" "$(basename "$abs")"
    printf 'Host source SHA-256: '; sha256sum "$abs" | cut -d' ' -f1
    podman --version
    printf 'Container image ID: '; podman image inspect --format '{{.Id}}' "$IMAGE"
    echo 'Harness scripts/configuration hashes:'
    (cd "$HERE" && sha256sum o77.sh Containerfile project/* scripts/*.sh tools/Probes.lean)
  } > "$log"
  info "Checking $(basename "$abs"); log: $log"
  local -a statuses
  # Explicitly retain both process exit statuses; tee must not hide a failed check.
  set +e
  podman run --rm --network=none --security-opt=no-new-privileges \
    -v "$VOLUME":/work \
    -v "$abs":/input/O77Target.lean:ro,Z \
    -v "$HERE/scripts":/opt/scripts:ro,Z \
    -v "$HERE/project":/opt/project:ro,Z \
    -v "$HERE/tools":/opt/tools:ro,Z \
    -e FRESH="${FRESH:-0}" -e EXTRA_OPTS="${EXTRA_OPTS:--DmaxErrors=0}" \
    "$IMAGE" bash "/opt/scripts/in-container-${action}.sh" /input/O77Target.lean \
    2>&1 | tee -a "$log"
  statuses=("${PIPESTATUS[@]}")
  set -e
  printf 'Container/check exit status: %s; log writer exit status: %s\n' \
    "${statuses[0]}" "${statuses[1]}" | tee -a "$log"
  info "Full log: $log"
  if [ "${statuses[0]}" -ne 0 ]; then return "${statuses[0]}"; fi
  return "${statuses[1]}"
}

cmd_doctor() {
  no_args "$@"; need_podman
  podman run --rm --network=none --security-opt=no-new-privileges \
    -v "$VOLUME":/work -v "$HERE/scripts":/opt/scripts:ro,Z \
    "$IMAGE" bash /opt/scripts/in-container-doctor.sh
}

cmd_manifest() {
  no_args "$@"; need_podman
  podman run --rm --network=none --security-opt=no-new-privileges \
    -v "$VOLUME":/work:ro "$IMAGE" cat /work/o77check/lake-manifest.json
}

cmd_shell() {
  no_args "$@"; need_podman
  podman run --rm -it --network=none --security-opt=no-new-privileges \
    -v "$VOLUME":/work -w /work/o77check "$IMAGE" bash
}

cmd_clean() {
  no_args "$@"; need_podman
  info "Removing only image $IMAGE and dependency volume $VOLUME. Sources and logs are retained."
  podman rmi "$IMAGE"
  podman volume rm "$VOLUME"
}

case "${1:-help}" in
  help|--help|-h) usage ;;
  preflight) shift; cmd_preflight "$@" ;;
  build) shift; cmd_build "$@" ;;
  setup) shift; cmd_setup "$@" ;;
  doctor) shift; cmd_doctor "$@" ;;
  verify|recheck|probe) action=$1; shift; cmd_check "$action" "$@" ;;
  manifest) shift; cmd_manifest "$@" ;;
  shell) shift; cmd_shell "$@" ;;
  report) shift; [ "$#" -eq 2 ] || die 'Usage: ./o77.sh report LOG SOURCE'
    python3 "$HERE/tools/report_errors.py" "$@" ;;
  clean) shift; cmd_clean "$@" ;;
  *) die "Unknown command: $1 (use ./o77.sh help)" ;;
esac
