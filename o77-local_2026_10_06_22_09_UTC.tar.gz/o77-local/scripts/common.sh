#!/usr/bin/env bash
# Shared container-side setup. Callers use set -euo pipefail.
O77_PROJECT=${O77_PROJECT:-/work/o77check}
O77_CONFIG_DIR=${O77_CONFIG_DIR:-/opt/project}
O77_PIN=664cbbe52927ce6acaa39ca35498336116e123b8
O77_TOOLCHAIN=leanprover/lean4:v4.34.0-rc2

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

enter_project() {
  [ -d "$O77_PROJECT" ] || fail 'Project missing; run ./o77.sh setup first.'
  cd "$O77_PROJECT"
  # Serialize access to the common build directory, including source replacement.
  exec 9> .o77-run.lock
  flock -n 9 || fail 'Another setup/check/editor operation holds the project lock.'
}

refresh_config() {
  [ -f "$O77_CONFIG_DIR/lakefile.toml" ] || fail 'Mounted Lake configuration missing.'
  cp -- "$O77_CONFIG_DIR/lakefile.toml" "$O77_CONFIG_DIR/lean-toolchain" "$O77_PROJECT/"
}

check_environment() {
  [ "$(cat lean-toolchain)" = "$O77_TOOLCHAIN" ] || fail 'Unexpected Lean toolchain pin.'
  [ -f lake-manifest.json ] || fail 'Dependency manifest missing; run ./o77.sh setup.'
  local resolved
  resolved=$(git -C .lake/packages/mathlib rev-parse HEAD)
  [ "$resolved" = "$O77_PIN" ] || fail "Mathlib is $resolved, expected $O77_PIN. Run setup."
  git -C .lake/packages/mathlib diff --quiet HEAD -- || fail 'Mathlib has tracked modifications.'
}

print_environment() {
  printf 'UTC: '; date -u +%Y-%m-%dT%H:%M:%SZ
  printf 'Toolchain pin: '; cat lean-toolchain
  lean --version
  lake --version
  printf 'Mathlib HEAD: '; git -C .lake/packages/mathlib rev-parse HEAD
  echo 'Configuration / resolved manifest hashes:'
  sha256sum lean-toolchain lakefile.toml lake-manifest.json
  echo 'Resolved dependency manifest (JSON):'
  cat lake-manifest.json
  printf '\n'
}

copy_source() {
  local src=$1 tmp
  [ -f "$src" ] || fail "Source missing: $src"
  tmp=$(mktemp "$O77_PROJECT/.O77Target.XXXXXX")
  # Do not continue with an old O77Target if a read/copy fails.
  if ! cp -- "$src" "$tmp"; then
    rm -f -- "$tmp"
    fail 'Source copy failed; no build was attempted.'
  fi
  if ! cmp -s -- "$src" "$tmp"; then
    rm -f -- "$tmp"
    fail 'Copied source differs from input; no build was attempted.'
  fi
  mv -f -- "$tmp" "$O77_PROJECT/O77Target.lean"
  echo 'SHA-256 of the exact copied source:'
  sha256sum O77Target.lean
}

prepare_check() {
  enter_project
  refresh_config
  check_environment
  print_environment
  copy_source "$1"
}
