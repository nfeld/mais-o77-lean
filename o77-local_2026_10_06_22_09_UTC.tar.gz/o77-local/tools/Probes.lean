/-
Statement-shape regression examples for O77Full.

These examples project the six clauses of AnswersO77, extract attained values,
and instantiate the main theorem at a zero target. They test the displayed
logical shapes. They do not independently certify the definitions of volume,
loss, ranks, singular data, or the intended interpretation of the problem.

Append this file to the submitted source using ./o77.sh probe FILE.lean.
No mathematical statement or proof in these examples was changed in the
October 6 checking-package refresh. Only explanatory comments were revised.
-/

namespace O77.Probes
open O77 O77.Native O77.Reconstruction0905

variable {I O H : ℕ} {Phi : RM O I}

/-! ### Clause-shape probes: each must typecheck by projection only. -/

/-- C1: on the fiber, the rank data holds, the threshold is positive, and the
band pair is characterised exactly. -/
example (h : AnswersO77 (H := H) Phi) (w : Parameters I O H) (hfit : w.2 * w.1 = Phi) :
    RankData I O H Phi.rank w.1.rank w.2.rank ∧
    0 < (candidateTwiceLambda I O H Phi.rank w.1.rank w.2.rank : ℝ) / 2 ∧
    ∀ lam : ℝ, ∀ m : ℕ, HasLocalBandPair Phi w lam m ↔
      lam = (candidateTwiceLambda I O H Phi.rank w.1.rank w.2.rank : ℝ) / 2 ∧
      m = candidateMultiplicity I O H Phi.rank w.1.rank w.2.rank :=
  h.1 w hfit

/-- C2: feasibility of a rank pair is EQUIVALENT to it being realised. -/
example (h : AnswersO77 (H := H) Phi) (a b : ℕ) :
    RankData I O H Phi.rank a b ↔
      ∃ w : Parameters I O H, w.2 * w.1 = Phi ∧ w.1.rank = a ∧ w.2.rank = b :=
  h.2.1 a b

/-- C3: on an exact-fit fiber, minimization is equivalent to the rank condition.
The exact-fit premise is supplied before projecting the equivalence. -/
example (h : AnswersO77 (H := H) Phi) (w : Parameters I O H) (hfit : w.2 * w.1 = Phi) :
    IsThresholdMinimizer Phi w ↔
      MinimumRankCondition I O H Phi.rank w.1.rank w.2.rank :=
  h.2.2.1 w hfit

/-- C4: the global threshold is the LEAST attained value. -/
example (h : AnswersO77 (H := H) Phi) :
    IsLeast {lam : ℝ | ∃ w : Parameters I O H, w.2 * w.1 = Phi ∧
      ∃ m : ℕ, HasLocalBandPair Phi w lam m}
      (globalThresholdFormula I O H Phi.rank) :=
  h.2.2.2.1

/-- C5: the multiplicity is the GREATEST attained value. -/
example (h : AnswersO77 (H := H) Phi) :
    IsGreatest {m : ℕ | ∃ w : Parameters I O H, IsThresholdMinimizer Phi w ∧
      ∃ lam : ℝ, HasLocalBandPair Phi w lam m}
      (if (I + O + H + Phi.rank) % 2 = 1 ∧ O + Phi.rank ≤ I + H ∧
        I + Phi.rank ≤ O + H ∧ H + Phi.rank ≤ I + O then 2 else 1) :=
  h.2.2.2.2.1

/-- C6: saddle rungs are populated, and every strictly-lower rung carries the
pair (1,1). -/
example (h : AnswersO77 (H := H) Phi)
    (D : O77.RungGeometry0906.SingularData I O Phi.rank) (hD : D.target = Phi) :
    (∀ k : ℕ, k ≤ Phi.rank → ∃ w : Parameters I O H, D.OnRung k w) ∧
    (∀ k : ℕ, k < Phi.rank → ∀ w : Parameters I O H, D.OnRung k w →
      HasLocalBandPair Phi w 1 1) :=
  h.2.2.2.2.2 D hD

/-! ### Non-vacuity probes.

A conjunction of universally quantified clauses can be true because nothing
satisfies the hypotheses. These extract EXISTENTIAL content, which cannot be
vacuous. `IsLeast S x` unfolds to `x ∈ S ∧ ∀ y ∈ S, x ≤ y`, so `.1` is a
membership — i.e. an actual witness. -/

/-- The threshold is ATTAINED: some parameter on the fiber really has a band
pair at the global threshold. This forbids the fiber being empty. -/
example (h : AnswersO77 (H := H) Phi) :
    ∃ w : Parameters I O H, w.2 * w.1 = Phi ∧
      ∃ m : ℕ, HasLocalBandPair Phi w (globalThresholdFormula I O H Phi.rank) m :=
  h.2.2.2.1.1

/-- The multiplicity is ATTAINED at a threshold minimizer. -/
example (h : AnswersO77 (H := H) Phi) :
    ∃ w : Parameters I O H, IsThresholdMinimizer Phi w ∧
      ∃ lam : ℝ, HasLocalBandPair Phi w lam
        (if (I + O + H + Phi.rank) % 2 = 1 ∧ O + Phi.rank ≤ I + H ∧
          I + Phi.rank ≤ O + H ∧ H + Phi.rank ≤ I + O then 2 else 1) :=
  h.2.2.2.2.1.1

/-! ### Instantiation probe.

The final theorem gives an existence statement at a specific zero target.
Failure to elaborate this example would require diagnosing either the source
or the example; it would not by itself establish that all premises are false.
-/

example : ∃ w : Parameters 2 2 2, w.2 * w.1 = (0 : RM 2 2) ∧
    ∃ m : ℕ, HasLocalBandPair (0 : RM 2 2) w
      (globalThresholdFormula 2 2 2 (0 : RM 2 2).rank) m :=
  (O77.answersO77 (0 : RM 2 2) (by norm_num) (by norm_num) (by simp)).2.2.2.1.1

/-
Further human audit should examine the band predicate itself. In particular,
the positivity of its lower bound is a meaningful independent check. No extra
anti-triviality example is executed by this file.
-/

end O77.Probes
