#!/usr/bin/env bash
# Build the submitted source, then replay its compiled declarations.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

[ "$#" -le 1 ] || fail 'Pass exactly one source file.'
FRESH=${FRESH:-0}
[[ "$FRESH" = 0 || "$FRESH" = 1 ]] || fail 'FRESH must be 0 or 1.'
prepare_check "${1:-/input/O77Target.lean}"

echo '==> lake build O77Target'
if time lake build O77Target; then
  echo 'Build exit status: 0'
else
  status=$?
  echo "Build failed (exit $status); kernel replay was not attempted."
  exit "$status"
fi

checker=(lake env leanchecker)
if [ "$FRESH" = 1 ]; then
  checker+=(--fresh)
  echo '==> Kernel replay: submitted module and its imported constants, in a fresh environment.'
else
  echo '==> Kernel replay: submitted module, starting from its imported environment.'
fi
checker+=(O77Target)
if time "${checker[@]}"; then
  echo 'Kernel replay exit status: 0'
else
  status=$?
  echo "Kernel replay failed (exit $status). Preserve the complete log for diagnosis."
  exit "$status"
fi
cat <<'MSG'
KERNEL RE-CHECK PASSED.
The build and requested replay completed successfully using Lean's own kernel.
This is a separate replay, not an independently implemented proof checker.
Any #guard_msgs assertions in the submitted source were checked during its build.
The known October 6 O77Full checkpoint contains seven axiom guards, including
O77.answersO77. This script does not assume every input file contains those guards.
This run does not certify that the definitions express the intended mathematics.
MSG
