# Checking-package refresh — 6 October 2026 (UTC)

This updates the user-supplied `o77-local.tar.gz`, SHA-256:
`463f1fb95b9614b8a25445146ca4f300bbbc7d5451d997328973af53ddd8ac4e`.

- Rewrote the README for the current O77Full endpoint; corrected historical
  conditional-Wishart descriptions, fixed guard counts, and removed unsupported
  security/certification claims and fixed runtime/resource predictions.
- Copy/configuration failures now abort. The copied source is compared to the
  input before building; one project lock serializes batch setup/checks.
- Explicitly preserve build, replay, and host logging exit statuses. Batch
  commands no longer allocate a pseudo-terminal, improving saved logs/CI use.
- Check the resolved Mathlib commit and tracked checkout state. New logs include
  versions, manifest, source hashes, configuration hashes, and container image ID.
- Persist downloaded toolchains in the named volume. Build/setup remain online;
  checking runs have no network access. Existing users must rebuild and set up.
- Preserve the three original user-supplied logs byte-for-byte. Their old
  messages are historical evidence and were not rewritten.
- Revised only comments in `tools/Probes.lean`; all active declarations and
  examples are unchanged. Removed its commented unfinished example.
- Diagnostic summaries now say what they observed, without calling undiagnosed
  or unreached modules "clean". They retain both error and warning counts.
- Removed `latest`, `split`, and `shellsplit` convenience commands and the old
  splitting helpers. Automatic checkpoint selection and conversion into a new
  module graph are outside this exact-file verification workflow. The original
  archive retains those tools; their former textual checks did not establish
  semantic equivalence of a split build.
- Added mocked regression tests for copy/build/replay failures, argument checks,
  pin mismatch, and propagation of container/log-writer exit statuses.

No mathematical Lean source was modified, and no new Lean or container run was
performed here. These script tests are not a mathematical verification receipt.
The current delivered proof remains a separate file in the parent repository.
