# Preserved verification logs

These are the three logs supplied in the original local-checking archive.
Their bytes are unchanged; `SHA256SUMS` records their hashes. They are output
from the older harness, not execution receipts for the revised scripts.

- `recheck-20261006-231522.log`: the October 6 recheck. Its source hash is
  `54dd6627468f7f1ad19784b8085e567806d0a087095a1f56a99bb920436acacc`, matching
  `O77Full_2026_10_06_20_50_UTC.lean`. It records a successful build and default
  module replay, starting from imports. It is not a `--fresh` replay.
- `recheck-20260908-164146.log`: historical September 8 recheck.
- `probe-20260908-165724.log`: historical September 8 probe run.

The old success banner says "six" guards, whereas the October 6 source contains
seven. It also describes replay in overly absolute terms. Retaining those
messages is preservation of the record, not endorsement of that wording.
Refer to the current README for the precise interpretation.

The embedded timestamps retain their original format and time zone assumptions;
the revised driver names future logs explicitly in UTC. Old logs contain ANSI
terminal/progress output; they are intentionally not reformatted.

To check preservation from this directory:

```bash
sha256sum -c SHA256SUMS
```
