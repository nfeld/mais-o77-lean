# What the verification evidence establishes

There are distinct questions in reviewing this development:

1. **Does Lean accept the proof of the declared proposition?** The build checks
   this in the selected environment. The current source's seven `#guard_msgs`
   axiom checks further constrain the reported axiom dependencies, including
   those of `O77.answersO77`. A different file must be inspected on its own.
2. **Can the compiled declarations be replayed?** `leanchecker` checks this
   using Lean's own kernel. Default replay starts from imports; `--fresh`
   replays imported constants too. Successful replay is additional evidence,
   not an independently implemented kernel or a guarantee against every bug.
3. **Does that proposition express the intended mathematics?** This requires
   reviewing the definitions and hypotheses, and relating them to the problem.
   Kernel acceptance alone cannot answer it.

The intended target is the radius-first, two-sided band-volume formulation of
O77, with product Lebesgue measure in original matrix entries. Human review
should examine at least:

- The loss, its factor `1/2`, Frobenius norm, entry measure, open balls, and
  strict band inequality about the value at the center.
- The order of radius and epsilon quantifiers and the allowed dependence of
  comparison constants; the positivity guards on the threshold and multiplicity.
- Exact-fit rank data and signed/cast arithmetic in the residual dimensions.
- The full minimum-threshold locus and attainment of both extrema, rather than
  only a formula at a preferred representative.
- Rung membership including both discarded-mode annihilation conditions, and
  quantification over every point of each nonoptimal rung.
- The concrete Wishart density statement used internally: exponent, measure,
  full orthant, and positive finite normalizer independent of both parameters.

## Bundled probes

`tools/Probes.lean` projects the six clauses of `AnswersO77`, extracts existence
from `IsLeast` and `IsGreatest`, and instantiates the headline theorem at a zero
target. Running `./o77.sh probe FILE` elaborates these examples after the source.
These are regression tests for the written logical shapes. They reuse the
source definitions and are not an independent specification of their meaning.
They do not include a proof that an identically zero volume cannot satisfy the
band predicate; a commented unfinished example from the old package was removed.

A failed probe calls for diagnosis: the source, the example, or an API use may
be wrong. A successful probe does not establish semantic correctness for every
underlying definition. The historical probe log records an earlier checkpoint;
it does not constitute a new probe run of the October 6 file.

## Independently reviewed statements

A reviewer can write a small reference specification and verify that the
headline theorem implies it. The value comes from independently reviewing the
reference definitions and hypotheses. Comparison tools, including Comparator
or an external proof checker, can then provide additional mechanical checks
within their documented scope and supported Lean versions. This package does
not install or invoke such tools, and does not claim version compatibility.

Extracting the same definitions from the submitted source and calling them a
reference specification does not by itself settle their mathematical adequacy.
Conversely, public sharing of a candid research draft need not wait for every
possible extra checker. Keep the exact source, its checks, and the remaining
human-review work explicit.
