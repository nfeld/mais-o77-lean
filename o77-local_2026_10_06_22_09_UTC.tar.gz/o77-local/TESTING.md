# Validation of this package refresh

On 6 October 2026 UTC:

- All 22 Python unittest cases passed using mocked Lean, Lake, Git, Podman,
  and failure-injection commands. No Lean compiler or container was executed.
- All seven shell files passed `bash -n` syntax checking.
- The devcontainer configuration parsed as JSON.
- The three original `.log` files matched the uploaded archive byte-for-byte.
- Removing comments and normalizing whitespace from old/new `Probes.lean`
  gave identical active declaration text.
- The separate main Lean source retained SHA-256
  `54dd6627468f7f1ad19784b8085e567806d0a087095a1f56a99bb920436acacc`.

Tests cover source-copy failure/mismatch, missing source/configuration/probes,
wrong or modified Mathlib, the project lock, build/replay/elaboration failures,
FRESH handling, logging failures, multiple-file rejection, offline/read-only
batch arguments, warmup cleanup, and diagnostic reporting of partial logs.

These tests establish script behavior under the mocked conditions. They do not
establish that the revised image builds or that Lean/Mathlib execute correctly
in it. Run `build`, `setup`, and `recheck` locally for that new evidence. The
preserved successful historical log refers to the original harness.
